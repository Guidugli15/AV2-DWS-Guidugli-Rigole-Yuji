# Organizador de Estudos — Etapa 2

API Flask para cadastrar e consultar usuários, matérias e tarefas no MySQL/MariaDB. As classes ficam em `models.py`, as operações do banco em `dao.py` e as rotas em `app.py`.

## Rodar no Windows

1. Abra o XAMPP e inicie o MySQL.
2. No phpMyAdmin, confirme se o banco `organizador_estudos` tem as tabelas `usuario`, `materia` e `tarefa`. Se ainda não tiver importado o banco, use o arquivo `banco/organizador_estudos.sql` na aba **Importar**. Se já estiver criado, pule a importação.
3. Abra o PowerShell nesta pasta e execute os comandos abaixo. O arquivo `.env` usa a configuração local padrão do XAMPP. Ajuste usuário, senha ou porta nele, se necessário.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe app.py
```

## Cadastrar e consultar

Deixe o Flask rodando e abra outro PowerShell. Cadastre um usuário, cadastre uma matéria para esse usuário e use o ID retornado para cadastrar a tarefa.

```powershell
$api = 'http://127.0.0.1:5000'
$usuario = Invoke-RestMethod "$api/usuarios" -Method Post -ContentType 'application/json' -Body (@{
    nome = 'Ana'
    email = 'ana@example.com'
    senha = 'SenhaDeExemplo123'
} | ConvertTo-Json)

$materia = Invoke-RestMethod "$api/materias" -Method Post -ContentType 'application/json' -Body (@{
    id_usuario = $usuario.id_usuario
    nome = 'Matematica'
} | ConvertTo-Json)

Invoke-RestMethod "$api/tarefas" -Method Post -ContentType 'application/json' -Body (@{
    id_materia = $materia.id_materia
    titulo = 'Revisar equacoes'
    prazo = '2026-11-17'
} | ConvertTo-Json)
```

Abra no navegador `http://127.0.0.1:5000/usuarios`, `http://127.0.0.1:5000/materias` ou `http://127.0.0.1:5000/tarefas` para consultar os registros. Cada rota aceita `GET` para listar e `POST` para cadastrar. A API grava o hash da senha e o exclui das respostas.

Em tarefas, `descricao` e `prazo` são opcionais. As prioridades são `baixa`, `media` (padrão) e `alta`. Os status são `pendente` (padrão), `em_andamento` e `concluida`.

## Commit

Use os arquivos desta pasta no repositório do Organizador de Estudos. O Git ignora `.env` e `.venv`. Inclua os diagramas da Etapa 1 no repositório se ainda estiverem apenas no BRModelo.
