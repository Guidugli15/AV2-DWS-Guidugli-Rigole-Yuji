from conexao import conectar


def consultar(sql):
    with conectar() as conexao, conexao.cursor() as cursor:
        cursor.execute(sql)
        return cursor.fetchall()


def inserir(sql, valores):
    with conectar() as conexao, conexao.cursor() as cursor:
        cursor.execute(sql, valores)
        conexao.commit()
        return cursor.lastrowid


class UsuarioDAO:
    def listar(self):
        return consultar("SELECT id_usuario, nome, email, criado_em FROM usuario ORDER BY id_usuario")

    def cadastrar(self, usuario):
        return inserir(
            "INSERT INTO usuario (nome, email, senha_hash) VALUES (%s, %s, %s)",
            (usuario.nome, usuario.email, usuario.senha_hash),
        )


class MateriaDAO:
    def listar(self):
        return consultar(
            "SELECT id_materia, id_usuario, nome, descricao FROM materia ORDER BY id_materia"
        )

    def cadastrar(self, materia):
        return inserir(
            "INSERT INTO materia (id_usuario, nome, descricao) VALUES (%s, %s, %s)",
            (materia.id_usuario, materia.nome, materia.descricao),
        )


class TarefaDAO:
    def listar(self):
        return consultar(
            """SELECT id_tarefa, id_materia, titulo, descricao, prazo, prioridade, status,
                      criada_em FROM tarefa ORDER BY id_tarefa"""
        )

    def cadastrar(self, tarefa):
        return inserir(
            """INSERT INTO tarefa (id_materia, titulo, descricao, prazo, prioridade, status)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (tarefa.id_materia, tarefa.titulo, tarefa.descricao, tarefa.prazo,
             tarefa.prioridade, tarefa.status),
        )
