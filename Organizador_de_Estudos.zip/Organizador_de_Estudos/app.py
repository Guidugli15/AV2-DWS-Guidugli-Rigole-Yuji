from datetime import date, datetime

from flask import Flask, jsonify, request
from pymysql import MySQLError

from dao import MateriaDAO, TarefaDAO, UsuarioDAO
from models import Materia, Tarefa, Usuario

app = Flask(__name__)
usuario_dao = UsuarioDAO()
materia_dao = MateriaDAO()
tarefa_dao = TarefaDAO()


def listar(dao):
    registros = [
        {campo: valor.isoformat() if isinstance(valor, (date, datetime)) else valor
         for campo, valor in registro.items()}
        for registro in dao.listar()
    ]
    return jsonify(registros)


def cadastrar(modelo, dao, campo_id):
    dados = request.get_json(silent=True)
    if not isinstance(dados, dict):
        return jsonify(erro="Envie um objeto JSON com Content-Type application/json."), 400
    try:
        registro = modelo.do_json(dados)
    except ValueError as erro:
        return jsonify(erro=str(erro)), 400
    return jsonify({campo_id: dao.cadastrar(registro)}), 201


@app.get("/")
def inicio():
    return jsonify(projeto="Organizador de Estudos", rotas=["/usuarios", "/materias", "/tarefas"])


@app.route("/usuarios", methods=["GET", "POST"])
def usuarios():
    if request.method == "GET":
        return listar(usuario_dao)
    return cadastrar(Usuario, usuario_dao, "id_usuario")


@app.route("/materias", methods=["GET", "POST"])
def materias():
    if request.method == "GET":
        return listar(materia_dao)
    return cadastrar(Materia, materia_dao, "id_materia")


@app.route("/tarefas", methods=["GET", "POST"])
def tarefas():
    if request.method == "GET":
        return listar(tarefa_dao)
    return cadastrar(Tarefa, tarefa_dao, "id_tarefa")


@app.errorhandler(MySQLError)
def erro_banco(erro):
    codigo = erro.args[0] if erro.args else None
    if codigo == 1452:
        campo = "id_usuario" if request.path == "/materias" else "id_materia"
        return jsonify(erro=f"O registro informado em {campo} não existe."), 400
    if codigo == 1049:
        return jsonify(erro="Banco não encontrado. Confira DB_NAME ou importe o SQL da Etapa 1."), 503
    if codigo in (1044, 1045, 2002, 2003, 2006, 2013):
        return jsonify(erro="Confira se o MySQL está iniciado e revise o arquivo .env."), 503
    app.logger.error("Erro do MySQL (código %s).", codigo)
    return jsonify(erro="Não foi possível concluir a operação no banco."), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
