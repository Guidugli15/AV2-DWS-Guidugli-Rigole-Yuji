from contextlib import contextmanager
from os import getenv
from pathlib import Path

import pymysql
from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"))


@contextmanager
def conectar():
    conexao = pymysql.connect(
        host=getenv("DB_HOST", "127.0.0.1"),
        port=int(getenv("DB_PORT", "3306")),
        user=getenv("DB_USER", "root"),
        password=getenv("DB_PASSWORD", ""),
        database=getenv("DB_NAME", "organizador_estudos"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=5,
    )
    try:
        yield conexao
    finally:
        conexao.close()
